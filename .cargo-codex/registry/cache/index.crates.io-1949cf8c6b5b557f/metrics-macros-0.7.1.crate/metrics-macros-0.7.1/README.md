# metrics-macros

This crate houses all of the procedural macros that are re-exported by `metrics`.  Refer to the
documentation for `metrics` to find examples and more information on the available macros.

## crate no longer used

As of `metrics` v0.22.0, this crate is no longer used. You can find the source code for this crate
by navigating to the Git tag that corresponds to the crate version. For example, the
`metrics-macros-v0.7.0` tag corresponds to the source code for `metrics-macros` v0.7.0.
