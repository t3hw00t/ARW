# Changelog

The changelog for all the release branches of `cedar-policy` is maintained on
the `main` branch. You can view the most up-to-date changelog
[here](https://github.com/cedar-policy/cedar/blob/main/cedar-policy/CHANGELOG.md).
