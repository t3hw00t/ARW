unsafe-libyaml-norway
==============

This library is [libyaml] translated from C to unsafe Rust with the assistance
of [c2rust].

[libyaml]: https://github.com/yaml/libyaml/tree/2c891fc7a770e8ba2fec34fc6b545c672beb37e6
[c2rust]: https://github.com/immunant/c2rust

```toml
[dependencies]
unsafe-libyaml = "0.2"
```

*Compiler support: requires rustc 1.60+*

## License

<a href="LICENSE-MIT">MIT license</a>, same as libyaml.
